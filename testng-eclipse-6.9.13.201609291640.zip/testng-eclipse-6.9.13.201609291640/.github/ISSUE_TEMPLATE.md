### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead

### Steps to reproduce
1. 
2. 
3. 

### Running Configuration
* Plugin Version: 
* (Optional) Plugin Git Revision: 
  (Since 6.9.11, you can get the plugin git revision via navigating "About Eclipse -> 'Installation Details' at left bottom -> 'Configuration' tab -> scroll down to '*** TestNG for Eclipse Details:' portion ")
* (Optional) Operating System: 
