package org.testng.eclipse.convert;

import junit.framework.TestCase;

/**
 * This class should not be converted (extends TestSuite).
 * 
 * @author Cedric Beust <cedric@beust.com>
 */
public class JUnit3NoConversionTest2 extends TestCase {

  public void f() {
  }
}
