package org.testng.eclipse.convert;

import junit.framework.TestCase;

/**
 * This class should not be converted (no test, setUp, tearDown method).
 *
 * @author Cedric Beust <cedric@beust.com>
 *
 */
public class JUnit3NoConversionTest1 extends TestCase {

  public void f() {
  }
}
