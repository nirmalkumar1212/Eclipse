package org.testng.eclipse.launch;

public class EmptyRemoteTestNG {

  public static void main(String[] args) {
//    System.out.println("Empty RemoteTestNG");
  }
}
